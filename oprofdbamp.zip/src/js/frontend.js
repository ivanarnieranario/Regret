/**
 * Scripts for Frontend Website
 */
 
$(document).ready(function() {
	console.log("Frontend Website");
});